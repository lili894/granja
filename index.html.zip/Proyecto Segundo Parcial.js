(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Proyecto Segundo Parcial_atlas_1", frames: [[0,0,960,640],[962,0,960,640],[0,642,960,640],[0,1284,960,640],[962,642,960,640],[962,1284,960,640]]},
		{name:"Proyecto Segundo Parcial_atlas_2", frames: [[1576,1327,76,76],[0,0,960,640],[0,642,960,640],[0,1284,960,640],[962,0,960,640],[962,642,612,408],[962,1052,612,408],[1848,1327,60,68],[962,1462,452,552],[1416,1462,496,503],[1576,642,365,683],[1719,1327,63,67],[1654,1327,63,71],[1784,1327,62,67]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.boton_siguienteremovebgpreview = function() {
	this.initialize(ss["Proyecto Segundo Parcial_atlas_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Cafeteria1 = function() {
	this.initialize(ss["Proyecto Segundo Parcial_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Cafeteria12 = function() {
	this.initialize(ss["Proyecto Segundo Parcial_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Cafeteria13 = function() {
	this.initialize(ss["Proyecto Segundo Parcial_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Cafeteria14 = function() {
	this.initialize(ss["Proyecto Segundo Parcial_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Cafeteria15 = function() {
	this.initialize(ss["Proyecto Segundo Parcial_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Cafeteria16 = function() {
	this.initialize(ss["Proyecto Segundo Parcial_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Cafeteria2 = function() {
	this.initialize(ss["Proyecto Segundo Parcial_atlas_2"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Cafeteria3 = function() {
	this.initialize(ss["Proyecto Segundo Parcial_atlas_2"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Cafeteria7 = function() {
	this.initialize(ss["Proyecto Segundo Parcial_atlas_2"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Cafeteria = function() {
	this.initialize(ss["Proyecto Segundo Parcial_atlas_2"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Cafeteria__1_removebgpreview = function() {
	this.initialize(ss["Proyecto Segundo Parcial_atlas_2"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Cafeteria__8_removebgpreview1 = function() {
	this.initialize(ss["Proyecto Segundo Parcial_atlas_2"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.checkremovebgpreview = function() {
	this.initialize(ss["Proyecto Segundo Parcial_atlas_2"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.imageremovebgpreview21 = function() {
	this.initialize(ss["Proyecto Segundo Parcial_atlas_2"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.imageremovebgpreview5 = function() {
	this.initialize(ss["Proyecto Segundo Parcial_atlas_2"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.imageremovebgpreview6 = function() {
	this.initialize(ss["Proyecto Segundo Parcial_atlas_2"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.inicioremovebgpreview = function() {
	this.initialize(ss["Proyecto Segundo Parcial_atlas_2"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.muteremovebgpreview = function() {
	this.initialize(ss["Proyecto Segundo Parcial_atlas_2"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.pausamusicaremovebgpreview1 = function() {
	this.initialize(ss["Proyecto Segundo Parcial_atlas_2"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.btnStop = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.muteremovebgpreview();
	this.instance.setTransform(-31.5,-35.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({scaleY:0.7183,x:-32,y:-25},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-32,-35.5,63.5,71);


(lib.btnSiguiente1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.boton_siguienteremovebgpreview();
	this.instance.setTransform(-50,-46,1.3158,1.2105);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({scaleY:1.0017,y:-38},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-50,-46,100,92);


(lib.btnSiguiente = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.Cafeteria__1_removebgpreview();
	this.instance.setTransform(-86.1,-62.1,0.2814,0.3044);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({scaleX:0.4317,scaleY:0.4417,x:-132,y:-90},0).wait(1).to({scaleX:0.288,scaleY:0.3044,x:-88,y:-62},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-132,-90,264.2,180.2);


(lib.btnRefri = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.imageremovebgpreview6();
	this.instance.setTransform(-106.5,-207.55,0.5837,0.6078);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({scaleX:0.7262,scaleY:0.7307,x:-132,y:-250},0).wait(1).to({scaleX:0.5727,scaleY:0.6193,x:-104,y:-212},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-132,-250,265.1,499.1);


(lib.btnPlay = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.pausamusicaremovebgpreview1();
	this.instance.setTransform(-31,-33.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({scaleY:0.7015,y:-23},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31,-33.5,62,67);


(lib.btnListo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.checkremovebgpreview();
	this.instance.setTransform(-42.1,-49.95,1.4034,1.4699);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({scaleY:1.1772,x:-42,y:-40},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-42.1,-49.9,84.30000000000001,99.9);


(lib.btnInicio = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Capa_1
	this.instance = new lib.inicioremovebgpreview();
	this.instance.setTransform(-53.5,-51.45,1.6981,1.5358);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({scaleY:0.9994,x:-54,y:-33},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-54,-51.4,107.5,102.9);


(lib.btnHornear = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_2 = function() {
		playSound("oventimersoundeffectMP3_128K");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(2).call(this.frame_2).wait(1));

	// Capa_1
	this.instance = new lib.imageremovebgpreview5();
	this.instance.setTransform(-168,-183.55,0.6774,0.7298);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({scaleX:0.8226,scaleY:0.8651,x:-204,y:-218},0).wait(1).to({scaleX:0.6612,scaleY:0.6902,x:-164,y:-174},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-204,-218,408,435.1);


(lib.btnGalleta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_2 = function() {
		playSound("galleta");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(2).call(this.frame_2).wait(1));

	// Capa_1
	this.instance = new lib.imageremovebgpreview21();
	this.instance.setTransform(-78.05,-96.05,0.3453,0.348);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({scaleX:0.425,scaleY:0.3915,x:-96,y:-108},0).wait(1).to({scaleX:0.3011,scaleY:0.2683,x:-68,y:-74},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-96,-108,192.1,216.1);


(lib.btnBatir = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_2 = function() {
		playSound("misc060");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(2).call(this.frame_2).wait(1));

	// Capa_1
	this.instance = new lib.Cafeteria__8_removebgpreview1();
	this.instance.setTransform(-140.05,-92,0.4577,0.451);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({scaleX:0.5622,scaleY:0.5981,x:-172,y:-122},0).wait(1).to({scaleX:0.4381,scaleY:0.4314,x:-134,y:-88},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-172,-122,344.1,244);


(lib.cpEscenario10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.btnInicio.on("click",irA2.bind(this));
		
		function irA2(e){
		this.parent.cambiarEscenario (new lib.cpEscenario1());	
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// inicio
	this.btnInicio = new lib.btnInicio();
	this.btnInicio.name = "btnInicio";
	this.btnInicio.setTransform(873.5,554.45);
	new cjs.ButtonHelper(this.btnInicio, 0, 1, 2);

	this.timeline.addTween(cjs.Tween.get(this.btnInicio).wait(1));

	// Capa_1
	this.instance = new lib.Cafeteria16();

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#99FFFF").s().p("EhK/AyAMAAAhj/MCV/AAAMAAABj/g");
	this.shape.setTransform(479,319.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cpEscenario10, new cjs.Rectangle(-1,-0.9,961,640.9), null);


(lib.cpEscenario9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.btnListo.on("click",irA2.bind(this));
		
		function irA2(e){
		this.parent.cambiarEscenario (new lib.cpEscenario10());	
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// btnListo
	this.btnListo = new lib.btnListo();
	this.btnListo.name = "btnListo";
	this.btnListo.setTransform(622,566.1);
	new cjs.ButtonHelper(this.btnListo, 0, 1, 2);

	this.timeline.addTween(cjs.Tween.get(this.btnListo).wait(1));

	// Refri
	this.btnRefri = new lib.btnRefri();
	this.btnRefri.name = "btnRefri";
	this.btnRefri.setTransform(301.5,373.55);
	new cjs.ButtonHelper(this.btnRefri, 0, 1, 2);

	this.timeline.addTween(cjs.Tween.get(this.btnRefri).wait(1));

	// Capa_1
	this.instance = new lib.Cafeteria15();

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#99FFFF").s().p("EhK/AyAMAAAhj/MCV/AAAMAAABj/g");
	this.shape.setTransform(479,319.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cpEscenario9, new cjs.Rectangle(-1,-0.9,961,640.9), null);


(lib.cpEscenario8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.btnRefri.on("click",irA2.bind(this));
		
		function irA2(e){
		this.parent.cambiarEscenario (new lib.cpEscenario9());	
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Refri
	this.btnRefri = new lib.btnRefri();
	this.btnRefri.name = "btnRefri";
	this.btnRefri.setTransform(301.5,373.55);
	new cjs.ButtonHelper(this.btnRefri, 0, 1, 2);

	this.timeline.addTween(cjs.Tween.get(this.btnRefri).wait(1));

	// Capa_1
	this.instance = new lib.Cafeteria14();
	this.instance.setTransform(0,-1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#99FFFF").s().p("EhK/AyAMAAAhj/MCV/AAAMAAABj/g");
	this.shape.setTransform(479,319.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cpEscenario8, new cjs.Rectangle(-1,-1,961,640.1), null);


(lib.cpEscenario7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.btnListo.on("click",irA2.bind(this));
		
		function irA2(e){
		this.parent.cambiarEscenario (new lib.cpEscenario8());	
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Hornear
	this.instance = new lib.btnHornear();
	this.instance.setTransform(480,336.55);
	new cjs.ButtonHelper(this.instance, 0, 1, 2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// btnListo
	this.btnListo = new lib.btnListo();
	this.btnListo.name = "btnListo";
	this.btnListo.setTransform(480,520.1);
	new cjs.ButtonHelper(this.btnListo, 0, 1, 2);

	this.timeline.addTween(cjs.Tween.get(this.btnListo).wait(1));

	// Capa_1
	this.instance_1 = new lib.Cafeteria13();
	this.instance_1.setTransform(0,-1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#99FFFF").s().p("EhK/AyAMAAAhj/MCV/AAAMAAABj/g");
	this.shape.setTransform(479,319.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance_1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cpEscenario7, new cjs.Rectangle(-1,-1,961,640.1), null);


(lib.cpEscenario6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.btnListo.on("click",irA2.bind(this));
		
		function irA2(e){
		this.parent.cambiarEscenario (new lib.cpEscenario7());	
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// batir
	this.btnBatir = new lib.btnBatir();
	this.btnBatir.name = "btnBatir";
	this.btnBatir.setTransform(472.05,284);
	new cjs.ButtonHelper(this.btnBatir, 0, 1, 2);

	this.timeline.addTween(cjs.Tween.get(this.btnBatir).wait(1));

	// btnListo
	this.btnListo = new lib.btnListo();
	this.btnListo.name = "btnListo";
	this.btnListo.setTransform(476.15,453.95);
	new cjs.ButtonHelper(this.btnListo, 0, 1, 2);

	this.timeline.addTween(cjs.Tween.get(this.btnListo).wait(1));

	// Capa_1
	this.instance = new lib.Cafeteria12();
	this.instance.setTransform(0,-1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#99FFFF").s().p("EhK/AyAMAAAhj/MCV/AAAMAAABj/g");
	this.shape.setTransform(479,319.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cpEscenario6, new cjs.Rectangle(-1,-1,961,640.1), null);


(lib.cpEscenario5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.btnListo.on("click",irA2.bind(this));
		
		function irA2(e){
		this.parent.cambiarEscenario (new lib.cpEscenario6());	
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Galleta
	this.btnGalleta = new lib.btnGalleta();
	this.btnGalleta.name = "btnGalleta";
	this.btnGalleta.setTransform(494.05,274.05);
	new cjs.ButtonHelper(this.btnGalleta, 0, 1, 2);

	this.timeline.addTween(cjs.Tween.get(this.btnGalleta).wait(1));

	// btnListo
	this.btnListo = new lib.btnListo();
	this.btnListo.name = "btnListo";
	this.btnListo.setTransform(486.1,453.95);
	new cjs.ButtonHelper(this.btnListo, 0, 1, 2);

	this.timeline.addTween(cjs.Tween.get(this.btnListo).wait(1));

	// Capa_1
	this.instance = new lib.Cafeteria7();

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#99FFFF").s().p("EhK/AyAMAAAhj/MCV/AAAMAAABj/g");
	this.shape.setTransform(479,319.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cpEscenario5, new cjs.Rectangle(-1,-0.9,961,640.9), null);


(lib.cpEscenario4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.btnSiguiente1.on("click",irA2.bind(this));
		
		function irA2(e){
		this.parent.cambiarEscenario (new lib.cpEscenario5());	
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// siguiente
	this.btnSiguiente1 = new lib.btnSiguiente1();
	this.btnSiguiente1.name = "btnSiguiente1";
	this.btnSiguiente1.setTransform(894,580);
	new cjs.ButtonHelper(this.btnSiguiente1, 0, 1, 2);

	this.timeline.addTween(cjs.Tween.get(this.btnSiguiente1).wait(1));

	// Capa_1
	this.instance = new lib.Cafeteria1();

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#99FFFF").s().p("EhK/AyAMAAAhj/MCV/AAAMAAABj/g");
	this.shape.setTransform(479,319.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cpEscenario4, new cjs.Rectangle(-1,-0.9,961,640.9), null);


(lib.cpEscenario3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.btnSiguiente1.on("click",irA2.bind(this));
		
		function irA2(e){
		this.parent.cambiarEscenario (new lib.cpEscenario4());	
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// siguiente
	this.btnSiguiente1 = new lib.btnSiguiente1();
	this.btnSiguiente1.name = "btnSiguiente1";
	this.btnSiguiente1.setTransform(894,580);
	new cjs.ButtonHelper(this.btnSiguiente1, 0, 1, 2);

	this.timeline.addTween(cjs.Tween.get(this.btnSiguiente1).wait(1));

	// Capa_1
	this.instance = new lib.Cafeteria3();

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#99FFFF").s().p("EhK/AyAMAAAhj/MCV/AAAMAAABj/g");
	this.shape.setTransform(479,319.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cpEscenario3, new cjs.Rectangle(-1,-0.9,961,640.9), null);


(lib.cpEscenario2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.btnSiguiente1.on("click",irA2.bind(this));
		
		function irA2(e){
		this.parent.cambiarEscenario (new lib.cpEscenario3());	
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// siguiente
	this.btnSiguiente1 = new lib.btnSiguiente1();
	this.btnSiguiente1.name = "btnSiguiente1";
	this.btnSiguiente1.setTransform(894,580);
	new cjs.ButtonHelper(this.btnSiguiente1, 0, 1, 2);

	this.timeline.addTween(cjs.Tween.get(this.btnSiguiente1).wait(1));

	// Capa_1
	this.instance = new lib.Cafeteria2();

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#99FFFF").s().p("EhK/AyAMAAAhj/MCV/AAAMAAABj/g");
	this.shape.setTransform(479,319.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cpEscenario2, new cjs.Rectangle(-1,-0.9,961,640.9), null);


(lib.cpEscenario1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var sonido = new createjs.Sound.play("audioMp3", {loop: -1});
		
		sonido.volumen = 0.5;
		
		function detenerSonido(){
				sonido.stop();
			}
		
		this.btnStop.addEventListener("click", detenerSonido);
		
		function iniciarSonido() {
			sonido.play();
		}
		
		this.btnPlay.addEventListener("click", iniciarSonido);
		this.btnSiguiente.on("click",irA2.bind(this));
		
		function irA2(e){
		this.parent.cambiarEscenario (new lib.cpEscenario2());	
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// btnStop
	this.btnStop = new lib.btnStop();
	this.btnStop.name = "btnStop";
	this.btnStop.setTransform(41.5,585.5);
	new cjs.ButtonHelper(this.btnStop, 0, 1, 2);

	this.timeline.addTween(cjs.Tween.get(this.btnStop).wait(1));

	// btnPlay
	this.btnPlay = new lib.btnPlay();
	this.btnPlay.name = "btnPlay";
	this.btnPlay.setTransform(95.95,583.5);
	new cjs.ButtonHelper(this.btnPlay, 0, 1, 2);

	this.timeline.addTween(cjs.Tween.get(this.btnPlay).wait(1));

	// siguiente
	this.btnSiguiente = new lib.btnSiguiente();
	this.btnSiguiente.name = "btnSiguiente";
	this.btnSiguiente.setTransform(522.1,420.1);
	new cjs.ButtonHelper(this.btnSiguiente, 0, 1, 2);

	this.timeline.addTween(cjs.Tween.get(this.btnSiguiente).wait(1));

	// Capa_1
	this.instance = new lib.Cafeteria();

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("EhK/AyAMAAAhj/MCV/AAAMAAABj/g");
	this.shape.setTransform(479,319.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cpEscenario1, new cjs.Rectangle(-1,-0.9,961,640.9), null);


// stage content:
(lib.ProyectoSegundoParcial = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var escenario=new lib.cpEscenario1();
		this.addChild(escenario);
		
		this.cambiarEscenario = function (nuevoEscenario){
			this.addChild(nuevoEscenario);
			this.removeChild(escenario);
			escenario=nuevoEscenario;
			
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);
// library properties:
lib.properties = {
	id: 'AE8A96029B071D4C809117F4124C51F0',
	width: 960,
	height: 640,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Proyecto Segundo Parcial_atlas_1.png?1743145292759", id:"Proyecto Segundo Parcial_atlas_1"},
		{src:"images/Proyecto Segundo Parcial_atlas_2.png?1743145292759", id:"Proyecto Segundo Parcial_atlas_2"},
		{src:"sounds/audioMp3.mp3?1743145292854", id:"audioMp3"},
		{src:"sounds/galleta.mp3?1743145292854", id:"galleta"},
		{src:"sounds/misc060.mp3?1743145292854", id:"misc060"},
		{src:"sounds/oventimersoundeffectMP3_128K.mp3?1743145292854", id:"oventimersoundeffectMP3_128K"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['AE8A96029B071D4C809117F4124C51F0'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;